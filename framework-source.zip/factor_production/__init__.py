"""Candidate production benchmark tools."""
